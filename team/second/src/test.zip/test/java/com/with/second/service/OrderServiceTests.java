package com.with.second.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.jaxb.SpringDataJaxb;


import java.util.stream.IntStream;

@SpringBootTest
public class OrderServiceTests {

    @Autowired
    private OrderService service;

    @Test
    public void register() {

        IntStream.rangeClosed(1,100).forEach(i ->{

            OrderDto
        })
    }
}