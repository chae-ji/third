package com.with.second;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondApplicationTests {

	@Test
	void contextLoads() {
	}

}
